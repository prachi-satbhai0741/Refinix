"""Build one Refinix internal test package on this computer's native OS.

The single build driver for every lane (macOS arm64, Windows x64, Ubuntu x86_64),
used the same way on a native host and in `.github/workflows/package.yml`:

    python desktop/build.py --version 0.1.0-internal.1 --build-set bs-0001 --out out/
    python desktop/build.py ... --plan          # digests and reuse decision only

What it guarantees:

* **One application.** Sources are staged by `packaging_plan.stage_application_sources`,
  the same boundary the macOS py2app build has always used; the three lanes
  share one source snapshot digest for the application, frontend and build code.
* **Pinned inputs.** Dependencies come from hash-pinned locks; the engine from
  `desktop/engine/engine-pins.json`; AppImage tooling from `packaging-tools.json`.
  Cached downloads are re-verified by hash before use. Built packages are never
  cached or restored.
* **No relabelling.** If the input identity (snapshot, locks, engine, interpreter,
  toolchain, runner image) matches a recorded build set *and* the retained
  artifact still exists with the recorded SHA-256, the build is skipped with
  "reuse"; otherwise a new labelled build is produced (or a rebuild reason is
  required).
* **Two identity records.** `refinix-build.json` is embedded in the package and
  never contains the package's own hash. After packaging, `<artifact>.sha256`
  and `<artifact>.manifest.json` record the final bytes, and the embedded
  identity is extracted from the finished artifact and compared.

Internal packages are unsigned test evidence. Signing, notarisation and
publication are separate, user-authorised steps.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform as _platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

DESKTOP = Path(__file__).resolve().parent
REPO = DESKTOP.parent
sys.path.insert(0, str(DESKTOP))
sys.path.insert(0, str(DESKTOP / "engine"))
import packaging_plan  # noqa: E402
import fetch as engine_fetch  # noqa: E402

IDENTITY_NAME = "refinix-build.json"
TOOLS = DESKTOP / "packaging-tools.json"
CHUNK = 4 * 1024 * 1024


class BuildError(RuntimeError):
    pass


# --------------------------------------------------------------------------
# Identity
# --------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(CHUNK), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"))
                          .encode("utf-8")).hexdigest()


def detect_lane(platform: str | None = None, machine: str | None = None) -> str:
    platform = sys.platform if platform is None else platform
    machine = (_platform.machine() if machine is None else machine).lower()
    machine = {"amd64": "x86_64", "aarch64": "arm64"}.get(machine, machine)
    for key, lane in packaging_plan.LANES.items():
        prefix, arch = lane.host
        if platform.startswith(prefix) and machine == arch:
            return key
    raise BuildError(f"no native build lane for {platform}/{machine}; PyInstaller "
                     "and py2app cannot cross-build another OS's package")


def _run_text(argv, **kwargs) -> str | None:
    try:
        return subprocess.run(argv, capture_output=True, text=True, timeout=60,
                              check=False, **kwargs).stdout.strip() or None
    except (OSError, subprocess.SubprocessError):
        return None


def toolchain_identity(lane: str) -> dict:
    """Everything outside the repository that shapes the produced bytes."""
    import sysconfig
    identity = {
        "python": _platform.python_version(),
        "python_implementation": _platform.python_implementation(),
        "python_build": list(_platform.python_build()),
        "python_compiler": _platform.python_compiler(),
        "python_base": str(Path(sys.base_prefix)),
        "macos_deployment_target": sysconfig.get_config_var("MACOSX_DEPLOYMENT_TARGET"),
        "host_platform": _platform.platform(),
        "glibc": "-".join(_platform.libc_ver()) if sys.platform.startswith("linux") else None,
        "runner_image": "/".join(filter(None, (os.environ.get("ImageOS"),
                                               os.environ.get("ImageVersion")))) or None,
        "tools": {},
    }
    for module in ("PyInstaller", "py2app"):
        try:
            imported = __import__(module)
            identity["tools"][module] = getattr(imported, "__version__", "unknown")
        except ImportError:
            continue
    if lane == "linux-x64":
        identity["apt"] = {name: _run_text(["dpkg-query", "-W", "-f=${Version}", name])
                           for name in ("python3-gi", "python3-gi-cairo",
                                        "gir1.2-webkit2-4.1", "libwebkit2gtk-4.1-0")}
    if lane == "windows-x64":
        identity["tools"]["iscc"] = find_iscc() and "present"
    return identity


def input_identity(lane: str, *, toolchain: dict | None = None) -> dict:
    snapshot, listing = packaging_plan.snapshot_digest(lane)
    pins = json.loads((DESKTOP / "engine" / "engine-pins.json").read_text(encoding="utf-8"))
    entry = packaging_plan.LANES[lane]
    components = {
        "lane": lane,
        "snapshot_digest": snapshot,
        "shared_snapshot_digest": packaging_plan.shared_snapshot_digest(),
        "locks": {path: sha256_file(REPO / path) for path in
                  entry.locks + entry.build_locks},
        "engines": {name: pins["lanes"][name]["sha256"] for name in entry.engines},
        "engine_release": pins["release"],
        "tools": json.loads(TOOLS.read_text(encoding="utf-8")),
        "toolchain": toolchain if toolchain is not None else toolchain_identity(lane),
    }
    return {"input_digest": canonical_digest(components), "components": components,
            "snapshot_files": len(listing)}


def find_reuse(records: list[dict], *, lane: str, input_digest: str,
               store: Path | None) -> dict | None:
    """A previous build set this one may reuse, only if its bytes still exist."""
    for record in records:
        if record.get("lane") != lane or record.get("input_digest") != input_digest:
            continue
        if store is None:
            return {**record, "reuse": False,
                    "reason": "matching inputs, but no artifact store was given to "
                              "check the retained bytes"}
        missing = []
        for artifact in record.get("artifacts", []):
            path = store / artifact["name"]
            if not path.is_file() or sha256_file(path) != artifact["sha256"]:
                missing.append(artifact["name"])
        if missing:
            return {**record, "reuse": False,
                    "reason": f"retained artifact missing or changed: {missing}"}
        return {**record, "reuse": True, "reason": "inputs unchanged and retained "
                                                   "artifacts verified"}
    return None


# --------------------------------------------------------------------------
# Engine
# --------------------------------------------------------------------------

def trim_engine(root: Path) -> None:
    """Keep only the server, its shared libraries and links, and the licence."""
    for path in sorted(root.rglob("*"), reverse=True):
        if path.name == engine_fetch.MANIFEST_NAME:
            continue
        if path.is_dir() and not path.is_symlink():
            if not any(path.iterdir()):
                path.rmdir()
            continue
        if not packaging_plan.engine_file_is_shipped(path.name):
            path.unlink()


def prepare_engines(lane: str, work: Path, cache: Path) -> list[dict]:
    pins = engine_fetch.load_pins()
    prepared = []
    for engine_lane in packaging_plan.LANES[lane].engines:
        target = work / "engine" / engine_lane
        engine_fetch.fetch(engine_lane, destination=target, cache=cache, pins=pins)
        trim_engine(target)
        manifest = engine_fetch.describe(target, pins, engine_lane)
        (target / engine_fetch.MANIFEST_NAME).write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        prepared.append({"lane": engine_lane, "path": target, "manifest": manifest,
                         "manifest_sha256": sha256_file(target / engine_fetch.MANIFEST_NAME)})
    return prepared


def place_engines(engines: list[dict], resources: Path) -> None:
    for item in engines:
        destination = resources / "engine" / item["lane"]
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(item["path"], destination, symlinks=True)


def verify_placed_engines(engines: list[dict], resources: Path) -> None:
    sys.path.insert(0, str(REPO))
    from backend.coordinator import engine as engine_module  # noqa: PLC0415
    for item in engines:
        root = resources / "engine" / item["lane"]
        problems = engine_module.verify(root, engine_module.load_manifest(root))
        if problems:
            raise BuildError(f"engine {item['lane']} failed verification in the "
                             f"package: {problems[:3]}")


# --------------------------------------------------------------------------
# Minimum OS
# --------------------------------------------------------------------------

_MACHO_MAGICS = {b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe", b"\xca\xfe\xba\xbe",
                 b"\xfe\xed\xfa\xcf", b"\xfe\xed\xfa\xce"}


def _version(text: str) -> tuple[int, ...]:
    return tuple(int(part) for part in text.split("."))


def macho_minos(path: Path) -> tuple[int, ...] | None:
    output = _run_text(["/usr/bin/otool", "-l", str(path)])
    if not output:
        return None
    found = [_version(m) for m in re.findall(r"\bminos (\d+(?:\.\d+)*)", output)]
    found += [_version(m) for m in re.findall(
        r"cmd LC_VERSION_MIN_MACOSX[\s\S]*?version (\d+(?:\.\d+)*)", output)]
    return max(found) if found else None


def macho_files(root: Path):
    for path in root.rglob("*"):
        if path.is_file() and not path.is_symlink():
            try:
                with open(path, "rb") as handle:
                    if handle.read(4) in _MACHO_MAGICS:
                        yield path
            except OSError:
                continue


def bundle_floor(root: Path) -> tuple[tuple[int, ...], str]:
    """The highest minimum macOS any shipped binary declares, and which one."""
    worst, which = (0,), ""
    for path in macho_files(root):
        minos = macho_minos(path)
        if minos and minos > worst:
            worst, which = minos, str(path.relative_to(root))
    return worst, which


def expected_macos_floor(engines: list[dict]) -> tuple[int, ...]:
    """Floor from the inputs, before building: interpreter, engine, renderer."""
    candidates = [Path(sys.base_prefix) / "Python"]
    candidates += [item["path"] / item["manifest"]["executable"] for item in engines]
    try:
        import pypdfium2_raw
        candidates.append(Path(pypdfium2_raw.__file__).parent / "libpdfium.dylib")
    except ImportError:
        pass
    floors = [m for m in (macho_minos(p) for p in candidates if p.is_file()) if m]
    return max(floors) if floors else (13, 3)


# --------------------------------------------------------------------------
# Platform tools
# --------------------------------------------------------------------------

def find_iscc() -> str | None:
    for candidate in (os.environ.get("ISCC"),
                      r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe",
                      r"C:\Program Files\Inno Setup 6\ISCC.exe"):
        if candidate and Path(candidate).is_file():
            return candidate
    return shutil.which("iscc")


def _check(argv, **kwargs) -> None:
    result = subprocess.run(argv, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        raise BuildError(f"{Path(argv[0]).name} failed ({result.returncode}): "
                         f"{(result.stderr or result.stdout)[-1500:]}")


def obtain_tool(name: str, cache: Path) -> Path:
    tool = json.loads(TOOLS.read_text(encoding="utf-8"))[name]
    cache.mkdir(parents=True, exist_ok=True)
    path = cache / f"{tool['sha256']}-{Path(tool['url']).name}"
    if not (path.is_file() and sha256_file(path) == tool["sha256"]):
        engine_fetch._download(tool["url"], path)
        if path.stat().st_size != tool["size"] or sha256_file(path) != tool["sha256"]:
            path.unlink(missing_ok=True)
            raise BuildError(f"{name} did not match its pinned SHA-256")
    path.chmod(0o755)
    return path


def build_macos(args, work: Path, identity_file: Path, engines: list[dict]) -> list[Path]:
    floor = expected_macos_floor(engines)
    env = dict(os.environ, REFINIX_BUILD_IDENTITY=str(identity_file),
               REFINIX_MIN_MACOS=".".join(map(str, floor)))
    dist = work / "dist"
    _check([sys.executable, str(DESKTOP / "setup_py2app.py"), "py2app",
            "--bdist-base", str(work / "py2app"), "--dist-dir", str(dist)],
           cwd=str(DESKTOP), env=env)
    app = dist / "Refinix.app"
    resources = app / "Contents" / "Resources"
    place_engines(engines, resources)
    verify_placed_engines(engines, resources)
    actual, which = bundle_floor(app)
    if actual > floor:
        raise BuildError(f"{which} needs macOS {'.'.join(map(str, actual))}, above the "
                         f"declared minimum {'.'.join(map(str, floor))}")
    # Adding the engine changed the bundle, so the ad-hoc signature is redone.
    # This is not Developer ID signing or notarisation.
    _check(["/usr/bin/codesign", "--force", "--deep", "--sign", "-", str(app)])
    _check(["/usr/bin/codesign", "--verify", "--deep", "--strict", str(app)])
    artifact = Path(args.out) / f"Refinix-{args.version}-macos-arm64.zip"
    _check(["/usr/bin/ditto", "-c", "-k", "--keepParent", str(app), str(artifact)])
    args.min_os = ".".join(map(str, floor))
    return [artifact]


def build_pyinstaller(work: Path, identity_file: Path, staged: Path,
                      engines: list[dict]) -> Path:
    env = dict(os.environ, REFINIX_STAGED_SOURCES=str(staged),
               REFINIX_BUILD_IDENTITY=str(identity_file))
    _check([sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean",
            "--distpath", str(work / "dist"), "--workpath", str(work / "pyi"),
            str(DESKTOP / "refinix.spec")], env=env)
    onedir = work / "dist" / "Refinix"
    resources = onedir / "_internal"
    place_engines(engines, resources)
    verify_placed_engines(engines, resources)
    shipped = [str(p.relative_to(onedir)).replace("\\", "/") for p in onedir.rglob("*")]
    forbidden = [p for p in shipped if "/worker/" in p or "/fixtures/" in p
                 or re.search(r"(^|/)(test_|fake_|check_)[^/]*\.py$", p)]
    if forbidden:
        raise BuildError(f"development files in the package: {forbidden[:5]}")
    if not (resources / IDENTITY_NAME).is_file():
        raise BuildError("the build identity is missing from the package")
    return onedir


def build_windows(args, work: Path, identity_file: Path, staged: Path,
                  engines: list[dict]) -> list[Path]:
    onedir = build_pyinstaller(work, identity_file, staged, engines)
    iscc = find_iscc()
    if not iscc:
        raise BuildError("Inno Setup (ISCC.exe) was not found on this build host")
    base = f"Refinix-{args.version}-windows-x64-setup"
    _check([iscc, f"/DAppVersion={args.version}", f"/DSourceDir={onedir}",
            f"/DOutputDir={Path(args.out).resolve()}", f"/DOutputBase={base}",
            str(DESKTOP / "windows" / "refinix.iss")])
    args.min_os = "Windows 11 (10.0.22000)"
    return [Path(args.out) / f"{base}.exe"]


def build_linux(args, work: Path, identity_file: Path, staged: Path,
                engines: list[dict], cache: Path) -> list[Path]:
    onedir = build_pyinstaller(work, identity_file, staged, engines)
    icon = packaging_plan.ICONS / "refinix-256.png"
    outputs = []
    # AppImage: one user-writable file; replaced atomically on update.
    appdir = work / "Refinix.AppDir"
    shutil.copytree(onedir, appdir / "usr" / "lib" / "refinix", symlinks=True)
    shutil.copy2(DESKTOP / "linux" / "AppRun", appdir / "AppRun")
    shutil.copy2(DESKTOP / "linux" / "refinix.desktop", appdir / "refinix.desktop")
    shutil.copy2(icon, appdir / "refinix.png")
    appimage = Path(args.out) / f"Refinix-{args.version}-linux-x86_64.AppImage"
    tool = obtain_tool("appimagetool", cache)
    runtime_file = obtain_tool("appimage_runtime", cache)
    _check([str(tool), "--runtime-file", str(runtime_file), str(appdir), str(appimage)],
           env=dict(os.environ, ARCH="x86_64", APPIMAGE_EXTRACT_AND_RUN="1"))
    outputs.append(appimage)
    # .deb: installed through App Center, which resolves GTK/WebKitGTK.
    tree = work / "deb"
    shutil.copytree(onedir, tree / "opt" / "refinix", symlinks=True)
    (tree / "usr" / "bin").mkdir(parents=True)
    os.symlink("/opt/refinix/Refinix", tree / "usr" / "bin" / "refinix")
    (tree / "usr" / "share" / "applications").mkdir(parents=True)
    shutil.copy2(DESKTOP / "linux" / "refinix.desktop",
                 tree / "usr" / "share" / "applications" / "refinix.desktop")
    for size in packaging_plan.LINUX_ICON_SIZES:
        folder = tree / "usr" / "share" / "icons" / "hicolor" / f"{size}x{size}" / "apps"
        folder.mkdir(parents=True)
        shutil.copy2(packaging_plan.ICONS / f"refinix-{size}.png", folder / "refinix.png")
    (tree / "DEBIAN").mkdir()
    control = (DESKTOP / "linux" / "control.in").read_text(encoding="utf-8")
    (tree / "DEBIAN" / "control").write_text(
        control.replace("@DEB_VERSION@", args.version.replace("-", "~")), encoding="utf-8")
    deb = Path(args.out) / f"refinix_{args.version.replace('-', '~')}_amd64.deb"
    _check(["dpkg-deb", "--build", "--root-owner-group", str(tree), str(deb)])
    outputs.append(deb)
    args.min_os = f"Ubuntu 24.04 or later (glibc {_platform.libc_ver()[1]} build host)"
    return outputs


# --------------------------------------------------------------------------
# Identity extraction and records
# --------------------------------------------------------------------------

def extract_identity(artifact: Path, work: Path) -> dict:
    """Read the embedded identity back out of the finished artifact."""
    name = artifact.name
    if name.endswith(".zip"):
        with zipfile.ZipFile(artifact) as bundle:
            return json.loads(bundle.read(f"Refinix.app/Contents/Resources/{IDENTITY_NAME}"))
    if name.endswith(".deb"):
        folder = work / "deb-check"
        _check(["dpkg-deb", "-x", str(artifact), str(folder)])
        return json.loads((folder / "opt" / "refinix" / "_internal" / IDENTITY_NAME)
                          .read_text(encoding="utf-8"))
    if name.endswith(".AppImage"):
        folder = work / "appimage-check"
        folder.mkdir(exist_ok=True)
        _check([str(artifact.resolve()), "--appimage-extract",
                f"usr/lib/refinix/_internal/{IDENTITY_NAME}"], cwd=str(folder))
        return json.loads((folder / "squashfs-root" / "usr" / "lib" / "refinix" / "_internal"
                           / IDENTITY_NAME).read_text(encoding="utf-8"))
    if name.endswith(".exe"):
        # Install into a private folder, read the identity, uninstall again.
        # This also proves a silent per-user install works on the build host.
        target = work / "install-check"
        _check([str(artifact.resolve()), "/VERYSILENT", "/SUPPRESSMSGBOXES",
                "/NORESTART", f"/DIR={target}"])
        try:
            return json.loads((target / "_internal" / IDENTITY_NAME).read_text(encoding="utf-8"))
        finally:
            uninstaller = target / "unins000.exe"
            if uninstaller.is_file():
                subprocess.run([str(uninstaller), "/VERYSILENT", "/SUPPRESSMSGBOXES"],
                               check=False)
    raise BuildError(f"unknown artifact type: {name}")


INSTALL_STEPS = {
    "macos-arm64": "1. Unzip the file and move **Refinix.app** to Applications.\n"
                   "2. Open it. Because this build is unsigned, macOS blocks the first "
                   "open: open System Settings → Privacy & Security and choose "
                   "**Open Anyway** for Refinix, then confirm.",
    "windows-x64": "1. Run the setup file. Because it is unsigned, Windows SmartScreen "
                   "may warn: choose **More info → Run anyway**.\n"
                   "2. Setup installs for your account only; no administrator password "
                   "is needed.",
    "linux-x64": "Either:\n- **AppImage:** in Files, open the file's Properties, turn on "
                 "**Executable as Program** (\"Allow executing\"), then double-click it; or\n"
                 "- **.deb:** double-click it to install with App Center (asks for your "
                 "password and installs GTK/WebKitGTK if needed).",
}
PREREQUISITES = {
    "macos-arm64": "- A Mac with an Apple M-series chip.",
    "windows-x64": "- Windows 11 x64 with the Microsoft Edge WebView2 Runtime (part of "
                   "Windows 11). Setup stops and explains if it is missing.\n"
                   "- A current graphics driver; Refinix uses the processor if no "
                   "usable graphics device is found.",
    "linux-x64": "- Ubuntu 24.04 desktop.\n- For the AppImage: FUSE (`fuse3`) and the "
                 "WebKitGTK 4.1 packages; Refinix explains if they are missing. The .deb "
                 "installs them itself.\n- A current graphics driver; otherwise the "
                 "processor is used.",
}
UNINSTALL = {
    "macos-arm64": "Move Refinix.app to the Bin.",
    "windows-x64": "Settings → Apps → Installed apps → Refinix → Uninstall.",
    "linux-x64": "Delete the AppImage file, or remove the package with App Center.",
}
LIMITATIONS = {
    "macos-arm64": "- Code validation in a sandbox is not available on macOS in this "
                   "build; Code changes keep the \"Not sandbox tested\" label.\n"
                   "- Scan reading (OCR) is not qualified yet.",
    "windows-x64": "- Code validation in a sandbox is not available on Windows in this "
                   "build.\n- Scan reading (OCR) is not qualified yet.\n- No qualified "
                   "model preset exists for Windows hardware yet; the setup screen says so.",
    "linux-x64": "- Code sandbox validation depends on this computer's kernel and "
                 "systemd features and is shown as unavailable when they are missing.\n"
                 "- Scan reading (OCR) is not qualified yet.\n- No qualified model preset "
                 "exists for Linux hardware yet; the setup screen says so.",
}


def finalize(artifact: Path, identity: dict, *, lane: str, min_os: str,
             work: Path) -> dict:
    extracted = extract_identity(artifact, work)
    if extracted != identity:
        raise BuildError(f"{artifact.name}: the embedded identity does not match the "
                         "requested build")
    digest, size = sha256_file(artifact), artifact.stat().st_size
    record = {"artifact": artifact.name, "size": size, "sha256": digest, "lane": lane,
              "minimum_os": min_os, "channel": identity["channel"],
              "signing": identity["signing"], "embedded_identity": identity,
              "embedded_identity_sha256": canonical_digest(identity),
              "finalized_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    (artifact.parent / f"{artifact.name}.sha256").write_text(
        f"{digest}  {artifact.name}\n", encoding="utf-8")
    (artifact.parent / f"{artifact.name}.manifest.json").write_text(
        json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    engines = ", ".join(f"{e['release']} {e['backend']}" for e in identity["engines"])
    notes = (DESKTOP / "TESTING.md.in").read_text(encoding="utf-8")
    for key, value in {
            "@ARTIFACT@": artifact.name, "@VERSION@": identity["version"],
            "@BUILD_SET@": identity["build_set"], "@SHA256@": digest,
            "@OS_LABEL@": lane, "@MIN_OS@": min_os, "@ENGINE@": engines,
            "@SOURCE_DIGEST@": identity["shared_snapshot_digest"],
            "@INSTALL_STEPS@": INSTALL_STEPS[lane], "@PREREQUISITES@": PREREQUISITES[lane],
            "@UNINSTALL_STEPS@": UNINSTALL[lane], "@LIMITATIONS@": LIMITATIONS[lane]}.items():
        notes = notes.replace(key, value)
    (artifact.parent / f"{artifact.name}.TESTING.md").write_text(notes, encoding="utf-8")
    return record


def build_identity(args, lane: str, inputs: dict, engines: list[dict]) -> dict:
    return {
        "identity_version": 1, "product": "Refinix", "version": args.version,
        "build_set": args.build_set, "channel": "internal", "signing": "unsigned",
        "lane": lane, "input_digest": inputs["input_digest"],
        "snapshot_digest": inputs["components"]["snapshot_digest"],
        "shared_snapshot_digest": inputs["components"]["shared_snapshot_digest"],
        "source_commit": args.source_commit,
        "locks": inputs["components"]["locks"],
        "engines": [{"lane": e["lane"], "release": e["manifest"]["release"],
                     "commit": e["manifest"]["commit"], "backend": e["manifest"]["backend"],
                     "archive_sha256": e["manifest"]["archive_sha256"],
                     "manifest_sha256": e["manifest_sha256"]} for e in engines],
        "toolchain": inputs["components"]["toolchain"],
        # The internal update trust root id is set when Section 4 adds it.
        "trust_root": args.trust_root,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--version", required=True)
    parser.add_argument("--build-set", required=True)
    parser.add_argument("--out", type=Path, default=REPO / "desktop" / "out")
    parser.add_argument("--records", type=Path, default=DESKTOP / "build-sets.json")
    parser.add_argument("--store", type=Path, help="folder holding retained artifacts")
    parser.add_argument("--cache", type=Path,
                        default=Path(tempfile.gettempdir()) / "refinix-build-cache")
    parser.add_argument("--source-commit", default=os.environ.get("GITHUB_SHA"))
    parser.add_argument("--trust-root", default=None)
    parser.add_argument("--rebuild-reason")
    parser.add_argument("--plan", action="store_true",
                        help="print digests and the reuse decision without building")
    args = parser.parse_args(argv)
    try:
        lane = detect_lane()
        inputs = input_identity(lane)
        records = (json.loads(args.records.read_text(encoding="utf-8"))
                   if args.records.is_file() else [])
        reuse = find_reuse(records, lane=lane, input_digest=inputs["input_digest"],
                           store=args.store)
        plan = {"lane": lane, "input_digest": inputs["input_digest"],
                "shared_snapshot_digest": inputs["components"]["shared_snapshot_digest"],
                "snapshot_digest": inputs["components"]["snapshot_digest"],
                "reuse": reuse}
        if args.plan:
            print(json.dumps(plan, indent=2))
            return 0
        if reuse and reuse.get("reuse") and not args.rebuild_reason:
            print(json.dumps({"result": "reuse", "build_set": reuse["build_set"],
                              "reason": reuse["reason"]}, indent=2))
            return 0
        args.out.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="refinix-build-") as directory:
            work = Path(directory)
            engines = prepare_engines(lane, work, args.cache)
            identity = build_identity(args, lane, inputs, engines)
            identity_file = work / IDENTITY_NAME
            identity_file.write_text(json.dumps(identity, indent=2, sort_keys=True) + "\n",
                                     encoding="utf-8")
            staged = packaging_plan.stage_application_sources(work / "staged")
            started = time.monotonic()
            if lane == "macos-arm64":
                artifacts = build_macos(args, work, identity_file, engines)
            elif lane == "windows-x64":
                artifacts = build_windows(args, work, identity_file, staged, engines)
            else:
                artifacts = build_linux(args, work, identity_file, staged, engines,
                                        args.cache)
            finals = [finalize(a, identity, lane=lane, min_os=args.min_os, work=work)
                      for a in artifacts]
        record = {"build_set": args.build_set, "version": args.version, "lane": lane,
                  "input_digest": inputs["input_digest"],
                  "shared_snapshot_digest": inputs["components"]["shared_snapshot_digest"],
                  "rebuild_reason": args.rebuild_reason,
                  "artifacts": [{"name": f["artifact"], "sha256": f["sha256"],
                                 "size": f["size"]} for f in finals],
                  "build_seconds": round(time.monotonic() - started, 1)}
        (args.out / f"build-record-{lane}.json").write_text(
            json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps(record, indent=2))
        return 0
    except (BuildError, engine_fetch.FetchError, FileNotFoundError) as exc:
        print(f"build failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
