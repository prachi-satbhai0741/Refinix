"""The managed engine as the rest of Refinix sees it.

`runtime.probe`, `runtime.model_capabilities` and `runtime.stream_chat` keep
their existing shapes and callers. When a managed engine is configured they are
answered here instead of from an external Ollama:

* **What is installed** comes from Refinix's own verified install records, not
  from whatever the engine can see. A model is listed only when its files are
  present; its digest is the Refinix model-manifest digest recorded at install.
* **What a model can do** comes from those records as well: vision only when a
  verified projector was installed with it.
* **How the engine runs it** comes from the reviewed preset for this model on
  this hardware tier. No preset means no launch: the request is refused rather
  than run with settings nobody qualified.

The model is loaded on first use, and the engine's own idle sleep releases its
memory after ten minutes without work.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from pathlib import Path

from backend.coordinator import engine, runtime_llamacpp


@dataclass(frozen=True)
class InstalledModel:
    model_id: str
    manifest_sha256: str
    weights: Path
    projector: Path | None = None
    sampling: dict = field(default_factory=dict)

    @property
    def capabilities(self) -> list[str]:
        return ["completion"] + (["vision"] if self.projector else [])

    def present(self) -> bool:
        return Path(self.weights).is_file() and (
            self.projector is None or Path(self.projector).is_file())


class LocalEngine:
    """Managed-engine answers for the runtime facade."""

    def __init__(self, selection: engine.Selection, data_root: Path, *,
                 registry, settings_for, managed: engine.ManagedEngine | None = None):
        self.selection = selection
        self.registry = registry              # () -> {model_id: InstalledModel}
        self.settings_for = settings_for      # (model_id) -> LaunchSettings | None
        self.engine = managed or (engine.ManagedEngine(selection, data_root)
                                  if selection.manifest else None)
        self._lock = threading.Lock()

    # -- observation ------------------------------------------------------
    def probe(self) -> dict:
        installed = {}
        try:
            installed = {k: v for k, v in self.registry().items() if v.present()}
        except Exception as exc:                           # noqa: BLE001
            error = f"model records unavailable: {exc}"
        else:
            error = None
        problems = list(self.selection.problems)
        if self.engine is not None and self.engine.last_error is not None:
            last = self.engine.last_error
        else:
            last = None
        loaded = None
        if self.engine is not None and self.engine.running and self.engine.model:
            loaded = {"model": self.engine.model.model_id, "size_bytes": None,
                      "size_vram_bytes": None, "expires_at": None}
        return {
            "reachable": self.selection.usable and self.engine is not None,
            "server_version": self.selection.runtime_version,
            "runtime": engine.LLAMA_CPP,
            "engine": self.engine.describe() if self.engine else self.selection.describe(),
            "models": sorted(installed),
            "digests": {k: v.manifest_sha256 for k, v in installed.items()},
            "loaded": loaded,
            "endpoint": "Refinix engine (loopback, started by Refinix)",
            "error": ("; ".join(problems) if problems else
                      (str(last) if last is not None else error)),
        }

    def capabilities(self, model_id: str) -> list[str] | None:
        try:
            record = self.registry().get(model_id)
        except Exception:                                  # noqa: BLE001
            return None
        return list(record.capabilities) if record and record.present() else None

    # -- execution --------------------------------------------------------
    def stream_chat(self, messages, *, profile, inference, should_cancel=None,
                    images=None, response_format=None, watch_class=None,
                    unavailable=RuntimeError):
        if self.engine is None or not self.selection.usable:
            raise unavailable("The Refinix engine is missing or was modified: "
                              + "; ".join(self.selection.problems or ["not installed"]))
        model_id = profile.model.model_id
        record = self.registry().get(model_id)
        if record is None or not record.present():
            raise unavailable(f"{model_id} is not installed on this computer.")
        # The profile names exact bytes. A record whose manifest differs is a
        # different model, however it is labelled.
        if record.manifest_sha256 != profile.model.manifest_sha256 \
                or profile.model.runtime != engine.LLAMA_CPP \
                or profile.model.runtime_version != self.selection.runtime_version:
            raise unavailable("the qualified profile is bound to different model "
                              "bytes or another engine build")
        settings = self.settings_for(model_id)
        if settings is None:
            raise unavailable(f"there is no reviewed engine preset for {model_id} "
                              "on this computer")
        try:
            endpoint = self.engine.ensure(
                engine.ModelFiles(model_id, Path(record.weights),
                                  Path(record.projector) if record.projector else None),
                settings, cancelled=should_cancel)
        except engine.EngineError as exc:
            if exc.code == "engine_cancelled":
                yield "cancelled", {}
                return
            raise unavailable(str(exc)) from exc
        yield from runtime_llamacpp.stream_chat(
            endpoint, messages, profile=profile, inference=inference,
            should_cancel=should_cancel, images=images,
            response_format=response_format, sampling=record.sampling,
            watch_class=watch_class, unavailable=unavailable)

    def stop(self) -> bool:
        return self.engine.stop() if self.engine is not None else False
