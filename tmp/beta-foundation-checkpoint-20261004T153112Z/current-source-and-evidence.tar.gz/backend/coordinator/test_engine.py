"""The managed engine boundary, the llama-server adapter and the backend.

Uses `fake_llama_server.py` started as a real process, so the ownership proof,
port handling, crash detection, Stop on a stalled stream and context overflow
are exercised over real loopback sockets. Nothing here loads a model.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from backend.contracts import profiles as inference_profiles
from backend.contracts import v1
from backend.coordinator import engine, local_engine, runtime, runtime_llamacpp

FAKE = Path(__file__).with_name("fake_llama_server.py")


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_root(base: Path, *, release="b11390") -> Path:
    root = base / "engine"
    root.mkdir()
    exe = root / "llama-server"
    shutil.copyfile(FAKE, exe)
    (root / "LICENSE").write_text("MIT", encoding="utf-8")
    manifest = {"manifest_version": 1, "kind": "llama.cpp", "component": "llama-server",
                "release": release, "commit": "test", "licence": "MIT", "source": "test",
                "lane": "macos-arm64", "backend": "metal", "archive_sha256": "0" * 64,
                "executable": "llama-server",
                "files": [{"path": "LICENSE", "size": 3, "sha256": _digest(root / "LICENSE")},
                          {"path": "llama-server", "size": exe.stat().st_size,
                           "sha256": _digest(exe)}]}
    (root / engine.MANIFEST_NAME).write_text(json.dumps(manifest), encoding="utf-8")
    return root


def python_spawn(config: Path):
    """Run the fake through the test interpreter on every OS."""
    def spawn(args, **kwargs):
        kwargs["env"] = dict(kwargs["env"], PYTHONDONTWRITEBYTECODE="1")
        return subprocess.Popen([sys.executable, args[0], *args[1:],
                                 "--fake-config", str(config)], **kwargs)
    return spawn


def profile_for(model_id="qwen-test", digest="a" * 64, runtime_version="b11390-metal",
                workflow=inference_profiles.CHAT, decoder=("text",)):
    values = {"model": {"model_id": model_id, "manifest_sha256": digest,
                        "runtime": "llama.cpp", "runtime_version": runtime_version},
              "target_profile_id": "test-tier", "workflow_mode": workflow,
              "qualified_context_tokens": 4096, "default_output_tokens": 256,
              "max_output_tokens": 256, "reasoning_modes": ["disabled", "enabled"],
              "default_reasoning": "disabled", "decoder_modes": list(decoder),
              "qualified_memory_bytes": None, "qualification_state": "qualified",
              "eligible": True, "evidence_kind": "measured", "evidence_ref": "test"}
    return v1.ExecutionProfile(profile_id=v1.execution_profile_id(values), **values)


class EngineBase(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.base = Path(self.dir.name)
        self.root = make_root(self.base)
        self.config = self.base / "fake-mode.json"
        self.set_mode("ok")
        self.weights = self.base / "model.gguf"
        self.weights.write_bytes(b"GGUF" + b"\0" * 64)
        self.selection = engine.select(environ={}, frozen=True, roots=[self.root])
        self.managed = engine.ManagedEngine(
            self.selection, self.base / "data", spawn=python_spawn(self.config),
            ports=range(39480, 39500))
        self.settings = engine.LaunchSettings(context_tokens=4096)

    def tearDown(self):
        self.managed.stop()
        self.dir.cleanup()

    def set_mode(self, mode, **extra):
        self.config.write_text(json.dumps({"mode": mode, **extra}), encoding="utf-8")

    def model(self):
        return engine.ModelFiles("qwen-test", self.weights)


class TestSelection(EngineBase):
    def test_an_intact_shipped_engine_is_selected_and_verified(self):
        self.assertEqual(self.selection.mode, engine.MANAGED)
        self.assertEqual(self.selection.problems, [])
        self.assertEqual(self.selection.runtime_version, "b11390-metal")

    def test_a_packaged_build_without_an_engine_never_falls_back_to_ollama(self):
        selection = engine.select(environ={}, frozen=True, roots=[])
        self.assertEqual((selection.mode, selection.kind), (engine.MANAGED, engine.LLAMA_CPP))
        self.assertFalse(selection.usable)

    def test_the_ollama_override_is_ignored_in_a_packaged_build(self):
        selection = engine.select(environ={"REFINIX_ENGINE": "ollama"}, frozen=True,
                                  roots=[self.root])
        self.assertEqual(selection.mode, engine.MANAGED)

    def test_a_source_checkout_may_choose_the_developer_engine_explicitly(self):
        selection = engine.select(environ={"REFINIX_ENGINE": "ollama"}, frozen=False,
                                  roots=[self.root])
        self.assertEqual(selection.mode, engine.DEVELOPER)

    def test_an_engine_on_path_is_never_used(self):
        decoy = self.base / "path"
        decoy.mkdir()
        shutil.copyfile(FAKE, decoy / "llama-server")
        with patch.dict(os.environ, {"PATH": str(decoy)}):
            selection = engine.select(environ=os.environ, frozen=True, roots=[])
        self.assertIsNone(selection.root)
        self.assertFalse(selection.usable)

    def test_a_modified_engine_file_is_reported_and_never_started(self):
        with open(self.root / "llama-server", "a", encoding="utf-8") as handle:
            handle.write("# tampered\n")
        selection = engine.select(environ={}, frozen=True, roots=[self.root])
        self.assertTrue(selection.problems)
        spawned = []
        managed = engine.ManagedEngine(selection, self.base / "data",
                                       spawn=lambda *a, **k: spawned.append(a))
        with self.assertRaises(engine.EngineError) as caught:
            managed.ensure(self.model(), self.settings)
        self.assertEqual(caught.exception.code, "engine_unverified")
        self.assertEqual(spawned, [])

    def test_a_file_modified_after_startup_is_caught_before_the_next_launch(self):
        self.managed.ensure(self.model(), self.settings)
        self.managed.stop()
        with open(self.root / "LICENSE", "a", encoding="utf-8") as handle:
            handle.write("!")
        with self.assertRaises(engine.EngineError) as caught:
            self.managed.ensure(self.model(), self.settings)
        self.assertEqual(caught.exception.code, "engine_unverified")


class TestLaneChoice(EngineBase):
    def _cpu_root(self):
        (self.base / "cpu-lane").mkdir()
        cpu = make_root(self.base / "cpu-lane")
        manifest = json.loads((cpu / engine.MANIFEST_NAME).read_text())
        manifest.update(backend="cpu", lane="linux-x64-cpu")
        (cpu / engine.MANIFEST_NAME).write_text(json.dumps(manifest))
        return cpu

    def _gpu_root(self):
        (self.base / "gpu-lane").mkdir()
        gpu = make_root(self.base / "gpu-lane")
        manifest = json.loads((gpu / engine.MANIFEST_NAME).read_text())
        manifest.update(backend="vulkan", lane="linux-x64-vulkan")
        (gpu / engine.MANIFEST_NAME).write_text(json.dumps(manifest))
        return gpu

    def test_the_gpu_build_is_used_when_its_device_is_present(self):
        gpu, cpu = self._gpu_root(), self._cpu_root()
        chosen = engine.select(environ={}, frozen=True, roots=[gpu, cpu],
                               devices=lambda s: [{"id": "Vulkan0", "memory_mib": 4096}])
        self.assertEqual(chosen.manifest["backend"], "vulkan")

    def test_without_a_gpu_device_the_cpu_build_is_used(self):
        gpu, cpu = self._gpu_root(), self._cpu_root()
        chosen = engine.select(environ={}, frozen=True, roots=[gpu, cpu],
                               devices=lambda s: [])
        self.assertEqual(chosen.manifest["backend"], "cpu")

    def test_a_modified_gpu_build_is_reported_not_swapped_for_the_cpu_build(self):
        gpu, cpu = self._gpu_root(), self._cpu_root()
        with open(gpu / "LICENSE", "a", encoding="utf-8") as handle:
            handle.write("changed")
        chosen = engine.select(environ={}, frozen=True, roots=[gpu, cpu],
                               devices=lambda s: [])
        self.assertEqual(chosen.manifest["backend"], "vulkan")
        self.assertTrue(chosen.problems)


class TestLaunch(EngineBase):
    def test_the_engine_starts_proves_ownership_and_stops(self):
        endpoint = self.managed.ensure(self.model(), self.settings)
        self.assertEqual(endpoint.host, "127.0.0.1")
        self.assertIn(endpoint.port, range(39480, 39500))
        self.assertTrue(self.managed.running)
        self.assertTrue(self.managed.record_path.exists())
        # The same model and settings reuse the running process.
        self.assertIs(self.managed.ensure(self.model(), self.settings), endpoint)
        self.assertTrue(self.managed.stop())
        self.assertFalse(self.managed.running)
        self.assertFalse(self.managed.record_path.exists())

    def test_every_qualified_setting_is_explicit_and_fitting_is_off(self):
        args = engine.LaunchSettings(context_tokens=8192, slots=2).arguments()
        self.assertIn("--fit", args)
        self.assertEqual(args[args.index("--fit") + 1], "off")
        self.assertEqual(args[args.index("-c") + 1], "16384")
        for flag in ("-np", "-ngl", "-ctk", "-ctv", "-fa", "--reasoning-format"):
            self.assertIn(flag, args)

    def test_a_listener_that_accepts_anyone_is_not_adopted(self):
        self.set_mode("anonymous")
        with self.assertRaises(engine.EngineError) as caught:
            self.managed.ensure(self.model(), self.settings)
        self.assertEqual(caught.exception.code, "engine_foreign")
        self.assertFalse(self.managed.running)

    def test_a_different_build_is_refused(self):
        self.set_mode("wrong_build")
        with self.assertRaises(engine.EngineError) as caught:
            self.managed.ensure(self.model(), self.settings)
        self.assertEqual(caught.exception.code, "engine_unverified")

    def test_an_engine_that_dies_while_loading_is_reported(self):
        self.set_mode("die")
        with self.assertRaises(engine.EngineError) as caught:
            self.managed.ensure(self.model(), self.settings)
        self.assertEqual(caught.exception.code, "engine_failed")
        self.assertIn("exit code 3", str(caught.exception))

    def test_a_missing_model_file_is_refused_before_launch(self):
        with self.assertRaises(engine.EngineError) as caught:
            self.managed.ensure(engine.ModelFiles("x", self.base / "absent.gguf"),
                                self.settings)
        self.assertEqual(caught.exception.code, "model_missing")

    def test_an_occupied_port_is_skipped_not_shared(self):
        first = engine._free_port(range(39440, 39470))
        self.managed._ports = range(first, first + 10)
        with socket.socket() as squatter:
            squatter.bind(("127.0.0.1", first))
            squatter.listen(1)
            endpoint = self.managed.ensure(self.model(), self.settings)
        self.assertNotEqual(endpoint.port, first)

    def test_inherited_engine_settings_never_reach_the_process(self):
        with patch.dict(os.environ, {"LLAMA_ARG_CTX_SIZE": "999999",
                                     "OLLAMA_HOST": "0.0.0.0"}):
            env = engine.minimal_environment(self.root, self.base)
        self.assertNotIn("LLAMA_ARG_CTX_SIZE", env)
        self.assertNotIn("OLLAMA_HOST", env)

    def test_cancelling_a_slow_start_stops_the_process(self):
        self.set_mode("never_ready")
        cancel = threading.Event()
        threading.Timer(0.6, cancel.set).start()
        with self.assertRaises(engine.EngineError) as caught:
            self.managed.ensure(self.model(), self.settings, cancelled=cancel.is_set)
        self.assertEqual(caught.exception.code, "engine_cancelled")
        self.assertFalse(self.managed.running)


class TestOrphans(EngineBase):
    def _orphan(self):
        port = engine._free_port(range(39470, 39480))
        return subprocess.Popen([sys.executable, str(self.root / "llama-server"),
                                 "--port", str(port), "--api-key", "k",
                                 "--fake-config", str(self.config)],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def test_a_provably_owned_orphan_is_stopped(self):
        import psutil
        orphan = self._orphan()
        try:
            self.managed.home.mkdir(parents=True)
            self.managed.record_path.write_text(json.dumps({
                "pid": orphan.pid,
                "create_time": psutil.Process(orphan.pid).create_time(),
                "executable": psutil.Process(orphan.pid).exe()}), encoding="utf-8")
            self.assertTrue(self.managed.reap_orphan())
            orphan.wait(timeout=5)
        finally:
            if orphan.poll() is None:
                orphan.kill()

    def test_a_recycled_pid_is_never_signalled(self):
        orphan = self._orphan()
        try:
            self.managed.home.mkdir(parents=True)
            self.managed.record_path.write_text(json.dumps({
                "pid": orphan.pid, "create_time": 1.0,
                "executable": "/somewhere/else"}), encoding="utf-8")
            self.assertFalse(self.managed.reap_orphan())
            time.sleep(0.2)
            self.assertIsNone(orphan.poll(), "an unrelated process was stopped")
        finally:
            orphan.kill()
            orphan.wait(timeout=5)


class _Registry:
    def __init__(self, records):
        self.records = records

    def __call__(self):
        return self.records


class TestAdapter(EngineBase):
    def backend(self, *, digest="a" * 64, settings=True, projector=None):
        record = local_engine.InstalledModel("qwen-test", digest, self.weights,
                                             projector)
        return local_engine.LocalEngine(
            self.selection, self.base / "data", registry=_Registry({"qwen-test": record}),
            settings_for=lambda _m: self.settings if settings else None,
            managed=self.managed)

    def run_stream(self, backend, *, reasoning="disabled", response_format=None,
                   should_cancel=None, images=None, profile=None):
        profile = profile or profile_for(
            decoder=("json_schema",) if response_format else ("text",))
        decoder = "json_schema" if response_format else "text"
        inference = inference_profiles.request(
            profile, reasoning=reasoning, decoder=decoder,
            decoder_schema_sha256=(inference_profiles.schema_sha256(response_format)
                                   if response_format else None))
        runtime.configure_managed(backend)
        try:
            return list(runtime.stream_chat([{"role": "user", "content": "hi"}],
                                            profile=profile, inference=inference,
                                            should_cancel=should_cancel, images=images,
                                            response_format=response_format))
        finally:
            runtime.configure_managed(None)

    def test_reasoning_is_progress_and_metrics_keep_their_names(self):
        records = self.run_stream(self.backend(), reasoning="enabled")
        kinds = [kind for kind, _ in records]
        self.assertEqual(kinds[0], "thinking")
        self.assertEqual("".join(p for k, p in records if k == "delta"), "Hello there.")
        done = records[-1][1]
        self.assertEqual(records[-1][0], "done")
        self.assertEqual((done["done_reason"], done["prompt_tokens"], done["output_tokens"],
                          done["tokens_per_s"], done["cached_prompt_tokens"]),
                         ("stop", 40, 3, 100.0, 8))
        self.assertEqual(done["reasoning"], "enabled")

    def test_cached_prompt_tokens_still_count_toward_the_context(self):
        final = {"choices": [{"finish_reason": "length"}],
                 "timings": {"prompt_n": 100, "cache_n": 3900, "predicted_n": 192}}
        profile = profile_for()
        inference = inference_profiles.request(profile, reasoning="disabled",
                                               decoder="text")
        done = runtime_llamacpp.metrics(final, inference=inference, profile=profile)
        self.assertEqual(done["prompt_tokens"], 4000)
        self.assertEqual(done["limit_reason"], "context")

    def test_reasoning_off_is_sent_as_the_template_switch(self):
        record = self.base / "request.json"
        self.set_mode("ok", record=str(record))
        records = self.run_stream(self.backend())
        self.assertNotIn("thinking", [k for k, _ in records])
        sent = json.loads(record.read_text(encoding="utf-8"))
        self.assertEqual(sent["chat_template_kwargs"], {"enable_thinking": False})
        self.assertEqual(sent["max_tokens"], 256)

    def test_a_length_stop_names_the_output_limit(self):
        self.set_mode("length")
        done = self.run_stream(self.backend())[-1][1]
        self.assertEqual(done["done_reason"], "length")
        self.assertEqual(done["limit_reason"], "unknown")

    def test_structured_output_is_sent_as_a_json_schema(self):
        record = self.base / "request.json"
        self.set_mode("ok", record=str(record))
        schema = {"type": "object", "properties": {"a": {"type": "string"}},
                  "required": ["a"]}
        self.run_stream(self.backend(), response_format=schema)
        sent = json.loads(record.read_text(encoding="utf-8"))
        self.assertEqual(sent["response_format"]["json_schema"]["schema"], schema)

    def test_an_image_rides_on_the_last_user_message(self):
        record = self.base / "request.json"
        self.set_mode("ok", record=str(record))
        self.run_stream(self.backend(), images=[b"\x89PNG..."])
        sent = json.loads(record.read_text(encoding="utf-8"))
        parts = sent["messages"][-1]["content"]
        self.assertEqual(parts[1]["type"], "image_url")
        self.assertTrue(parts[1]["image_url"]["url"].startswith("data:image/png;base64,"))

    def test_context_overflow_is_refused_not_trimmed(self):
        self.set_mode("overflow")
        with self.assertRaises(runtime.RuntimeUnavailable) as caught:
            self.run_stream(self.backend())
        self.assertIn("Context window exceeded", str(caught.exception))

    def test_a_malformed_stream_is_an_error_not_an_answer(self):
        self.set_mode("malformed")
        with self.assertRaises(runtime.RuntimeUnavailable):
            self.run_stream(self.backend())

    def test_stop_ends_a_stalled_stream_promptly(self):
        self.set_mode("stall")
        cancel = threading.Event()
        started = time.monotonic()
        threading.Timer(1.0, cancel.set).start()
        records = self.run_stream(self.backend(), should_cancel=cancel.is_set)
        self.assertEqual(records[-1][0], "cancelled")
        self.assertLess(time.monotonic() - started, 8.0)

    def test_a_profile_for_other_bytes_is_refused(self):
        with self.assertRaises(runtime.RuntimeUnavailable) as caught:
            self.run_stream(self.backend(digest="b" * 64))
        self.assertIn("different model bytes", str(caught.exception))

    def test_a_profile_for_another_engine_build_is_refused(self):
        with self.assertRaises(runtime.RuntimeUnavailable):
            self.run_stream(self.backend(),
                            profile=profile_for(runtime_version="b10000-metal"))

    def test_no_reviewed_preset_means_no_launch(self):
        with self.assertRaises(runtime.RuntimeUnavailable) as caught:
            self.run_stream(self.backend(settings=False))
        self.assertIn("no reviewed engine preset", str(caught.exception))
        self.assertFalse(self.managed.running)

    def test_probe_reports_installed_records_and_the_engine_identity(self):
        backend = self.backend(projector=None)
        runtime.configure_managed(backend)
        try:
            state = runtime.probe()
            self.assertEqual(state["runtime"], "llama.cpp")
            self.assertEqual(state["server_version"], "b11390-metal")
            self.assertEqual(state["models"], ["qwen-test"])
            self.assertEqual(state["digests"], {"qwen-test": "a" * 64})
            self.assertEqual(runtime.model_capabilities("qwen-test"), ["completion"])
            self.assertIsNone(runtime.model_capabilities("absent"))
        finally:
            runtime.configure_managed(None)


class TestListDevices(unittest.TestCase):
    def test_the_engine_device_listing_is_parsed(self):
        selection = engine.Selection(engine.MANAGED, engine.LLAMA_CPP, "t", Path("/x"),
                                     {"executable": "llama-server", "release": "b1",
                                      "backend": "metal"}, [])
        output = ("Available devices:\n  MTL0: Apple M5 (12124 MiB, 12123 MiB free)\n"
                  "  BLAS: Accelerate (0 MiB, 0 MiB free)\n")
        result = subprocess.CompletedProcess([], 0, output, "")
        devices = engine.list_devices(selection, run=lambda *a, **k: result)
        self.assertEqual(devices[0], {"id": "MTL0", "name": "Apple M5",
                                      "memory_mib": 12124, "free_mib": 12123})

    def test_an_unverified_engine_is_not_asked(self):
        selection = engine.Selection(engine.MANAGED, engine.LLAMA_CPP, "t", None, None,
                                     ["missing"])
        self.assertIsNone(engine.list_devices(selection))


if __name__ == "__main__":
    unittest.main(verbosity=2)
